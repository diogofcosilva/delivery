package com.diogo.deliveryeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
