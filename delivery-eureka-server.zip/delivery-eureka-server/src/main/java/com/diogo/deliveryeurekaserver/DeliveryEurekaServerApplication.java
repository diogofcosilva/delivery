package com.diogo.deliveryeurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryEurekaServerApplication.class, args);
	}

}
