package com.diogo.deliveryauthserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryAuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
